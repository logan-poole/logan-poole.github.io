// scripts/config.js
window.PINGED_CONFIG = {
  
  SUPABASE_URL: "https://upacsqjjvlssyxiasbzw.supabase.co",
  SUPABASE_ANON_KEY: "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6InVwYWNzcWpqdmxzc3l4aWFzYnp3Iiwicm9sZSI6ImFub24iLCJpYXQiOjE3NTI0NTM5MzksImV4cCI6MjA2ODAyOTkzOX0.iJ_ykF_SSsRylvccCo7u9KC7-vQBf7G8lPUaFUrPgn4",

  MAPBOX_ACCESS_TOKEN: "pk.eyJ1IjoibG9nYW5wb29sZSIsImEiOiJjbWR3ZjNmamkyNDRmMmtwenl5MW41MDZxIn0.gRso7kVTaJfJWYAA7ruRjw",

};
