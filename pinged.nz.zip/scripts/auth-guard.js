/* scripts/auth-guard.js  — robust against races & mis-flags */
(function () {
  const qsa = (s, r = document) => Array.from(r.querySelectorAll(s));
  const showPublic = (on) => qsa('[data-auth="public"],[data-auth="guest"]').forEach(el => {
    el.hidden = !on; el.classList.toggle('hidden', !on); el.style.display = on ? '' : 'none';
  });
  const showProtected = (on) => qsa('[data-auth="protected"],[data-auth="authed"]').forEach(el => {
    el.hidden = !on; el.classList.toggle('hidden', !on); el.style.display = on ? '' : 'none';
  });

  function flags() {
    const b = document.body?.dataset || {};
    return {
      needAuth:   b.requireAuth === 'true',
      publicOnly: b.publicOnly  === 'true',
    };
  }

  function nukeOverlay() {
    const ov = document.getElementById('auth-overlay');
    if (!ov) return;
    ov.setAttribute('aria-hidden', 'true');
    ov.style.display = 'none';
  }

  function rememberNext() {
    const next = location.pathname + location.search + location.hash;
    try { localStorage.setItem('pinged_return_to', next); } catch {}
  }
  function popNext() {
    try {
      const s = localStorage.getItem('pinged_return_to');
      if (s) { localStorage.removeItem('pinged_return_to'); return s; }
    } catch {}
    return null;
  }
  function afterLoginTarget() {
    const urlNext = new URLSearchParams(location.search).get('next');
    return urlNext || popNext() || 'dashboard.html';
  }
  function isCurrent(target) {
    const here = location.pathname.split('/').pop() || 'index.html';
    return here === target || ('/' + here) === target || here.endsWith('/' + target);
  }

  // --- Wait helpers ----------------------------------------------------------
  function getSBNow() {
    return (window.getSB && window.getSB()) || window.__sb || null;
  }
  function sleep(ms) { return new Promise(r => setTimeout(r, ms)); }

  async function waitForSB(maxMs = 1500) {
    const start = Date.now();
    while (Date.now() - start < maxMs) {
      const sb = getSBNow();
      if (sb) return sb;
      await sleep(50);
    }
    return null;
  }

  async function waitForInitialSession(sb, maxMs = 1200) {
    // Try immediate session read first
    try {
      const { data } = await sb.auth.getSession();
      if (data?.session) return data.session;
    } catch {}
    // Fallback: wait for INITIAL_SESSION (or any event) briefly
    let resolved = null;
    const unsub = sb.auth.onAuthStateChange((evt, session) => {
      if (!resolved && (evt === 'INITIAL_SESSION' || evt === 'SIGNED_IN' || evt === 'TOKEN_REFRESHED')) {
        resolved = session || null;
      }
    });
    const start = Date.now();
    while (Date.now() - start < maxMs && resolved === null) {
      await sleep(50);
    }
    try { unsub?.data?.subscription?.unsubscribe?.(); } catch {}
    return resolved;
  }

  // --- Core flow -------------------------------------------------------------
  async function initialRefresh() {
    const { needAuth, publicOnly } = flags();

    // Show public by default to avoid empty header; hide protected until we know.
    showPublic(true); showProtected(false);

    // Ensure Supabase client exists before making decisions.
    const sb = await waitForSB();
    if (!sb) {
      if (needAuth) {
        rememberNext();
        return location.replace('index.html?signin=1');
      }
      return; // public page — do nothing
    }

    // Give Supabase a moment to hydrate INITIAL_SESSION to avoid false redirects.
    const session = await waitForInitialSession(sb);
    const authed = !!session?.user;

    nukeOverlay();
    showProtected(authed);
    showPublic(!authed);

    if (!authed && needAuth) {
      rememberNext();
      return location.replace('index.html?signin=1');
    }
    if (authed && publicOnly) {
      // User is logged in but this page is public-only (e.g., index/faq/terms/etc.)
      return location.replace('dashboard.html');
    }
    // Otherwise: stay on this page.
  }

  // Run after DOM is ready so body.dataset flags exist.
  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', initialRefresh);
  } else {
    initialRefresh();
  }

  // Only redirect on real sign-in or explicit "next" — never on token refresh/initial session.
  (async function wireLiveAuth() {
    const sb = await waitForSB(2000);
    if (!sb) return;

    sb.auth.onAuthStateChange(async (evt, session) => {
      const { needAuth, publicOnly } = flags();
      const authed = !!session?.user;

      nukeOverlay();
      showProtected(authed); showPublic(!authed);

      if (authed) {
        if (publicOnly) return location.replace('dashboard.html');

        const hasNext = !!new URLSearchParams(location.search).get('next') ||
                        !!localStorage.getItem('pinged_return_to');

        if (evt === 'SIGNED_IN' || evt === 'PASSWORD_RECOVERY' || hasNext) {
          const target = afterLoginTarget();
          if (target && !isCurrent(target)) location.replace(target);
        }
        // INITIAL_SESSION/TOKEN_REFRESHED → stay put
      } else if (needAuth) {
        rememberNext();
        location.replace('index.html?signin=1');
      }
    });
  })();

  // Optional sign-out convenience hook
  document.getElementById('btnSignOut')?.addEventListener('click', async () => {
    try { const sb = getSBNow(); await sb?.auth?.signOut(); } catch {}
    location.replace('index.html');
  });
})();
