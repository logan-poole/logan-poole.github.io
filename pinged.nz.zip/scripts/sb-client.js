/* scripts/sb-client.js */
(function () {
  function makeClient() {
    const cfg = window.PINGED_CONFIG || {};
    const NS = window.supabase;
    if (!NS?.createClient) {
      console.warn('[sb-client] supabase-js not loaded yet.');
      return null;
    }
    if (!cfg.SUPABASE_URL || !cfg.SUPABASE_ANON_KEY) {
      console.warn('[sb-client] Missing SUPABASE_URL or SUPABASE_ANON_KEY in scripts/config.js');
      return null;
    }
    try { return NS.createClient(cfg.SUPABASE_URL, cfg.SUPABASE_ANON_KEY); }
    catch (e) { console.warn('[sb-client] createClient failed:', e); return null; }
  }

  window.getSB = function getSB() {
    if (window.__sb) return window.__sb;
    window.__sb = makeClient();
    if (window.__sb) {
      try { window.dispatchEvent(new CustomEvent('pinged:sb', { detail: { ok: true } })); } catch { }
    }
    return window.__sb;
  };

  window.hasSB = function hasSB() { return !!window.getSB(); };

  document.addEventListener('DOMContentLoaded', () => {
    if (!window.hasSB()) console.warn('[sb-client] Not initialized. Check load order & config.');
  });
})();
